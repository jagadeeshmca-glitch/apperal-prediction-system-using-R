# Apparel Productivity Prediction and Analysis

This project analyzes garment worker productivity data to predict actual productivity and classify whether a team meets its target productivity. It combines data cleaning, exploratory analysis, statistical testing, multiple regression models, and a classification model in a single reproducible workflow.

## Project Goal

The system aims to:

- predict actual productivity for garment production teams
- determine whether the team meets its targeted productivity
- identify the most important factors affecting productivity
- compare several regression models and select the best performer
- generate visual reports and presentation-ready plots

## Dataset

The project uses the garment worker productivity dataset, which contains production-floor variables such as:

- quarter
- department
- day
- team
- targeted_productivity
- smv
- wip
- over_time
- incentive
- idle_time
- idle_men
- no_of_style_change
- no_of_workers
- actual_productivity

The dataset is stored as:

- `garments_worker_productivity.csv`

## Project Structure

```text
.
├── apparel_prediction.R           # Main R analysis and modeling script
├── insert_plots.py                # Inserts generated plots into the presentation
├── garments_worker_productivity.csv
├── requirements.txt               # Python package dependencies
├── Final_PPT.pptx                 # Final presentation after plot insertion
├── Apparel_Manufacturing_Prediction_R_Project_PPT.pptx
├── outputs/
│   ├── cleaned_garment_data.csv
│   ├── model_comparison.csv
│   ├── logistic_confusion_matrix.txt
│   ├── new_order_predictions.csv
│   ├── test_predictions.csv
│   ├── best_random_forest_model.rds
│   ├── logistic_model.rds
│   └── plots/
│       ├── 01_target_distribution.png
│       ├── 02_productivity_by_department.png
│       ├── 03_productivity_by_day.png
│       ├── 04_boxplots.png
│       ├── 05_correlation_matrix.png
│       ├── 06_incentive_vs_productivity.png
│       ├── 07_decision_tree.png
│       ├── 08_model_comparison.png
│       ├── 09_feature_importance.png
│       ├── 10_confusion_matrix.png
│       ├── AvP_Linear_Regression.png
│       ├── AvP_Ridge_Regression.png
│       ├── AvP_Lasso_Regression.png
│       ├── AvP_Decision_Tree.png
│       ├── AvP_Random_Forest.png
│       └── AvP_Stepwise_Regression.png
└── README.md
```

## Technologies Used

- R Programming
- ggplot2
- dplyr
- tidyr
- corrplot
- caret
- ranger
- rpart
- glmnet
- car
- lmtest
- Python 3
- python-pptx
- Pillow

## Workflow

The R script performs the following steps:

1. installs required R packages automatically if missing
2. loads and validates the dataset
3. cleans missing values and inconsistent labels
4. performs exploratory data analysis
5. runs statistical tests and checks for data issues
6. trains multiple regression models
7. compares model performance with RMSE, MAE, and R²
8. trains a logistic regression classifier for target-meeting prediction
9. predicts productivity for new production scenarios
10. saves all outputs to the `outputs` folder

## How to Run

### 1. Install R

Install R 4.5+ or later from the official CRAN website.

### 2. Install Python dependencies

```bash
python -m pip install -r requirements.txt
```

### 3. Run the project analysis

From the project folder:

```bash
Rscript apparel_prediction.R
```

This will generate the plots, tables, and saved model files in the `outputs` folder.

### 4. Insert plots into the presentation

The project contains a PowerPoint template with note markers like:

```text
PLOT: 01_target_distribution.png
```

To insert all plots into the presentation:

```bash
python insert_plots.py "Apparel_Manufacturing_Prediction_R_Project_PPT.pptx" outputs/plots "Final_PPT.pptx"
```

## Key Results

The project compares several models for regression performance, with the best model selected using RMSE:

- Random Forest
- Decision Tree
- Ridge Regression
- Lasso Regression
- Linear Regression
- Stepwise Regression

The final model is saved as:

- `outputs/best_random_forest_model.rds`

The classification model for target success is saved as:

- `outputs/logistic_model.rds`

## Output Files

The script exports the following important artifacts:

- `outputs/cleaned_garment_data.csv`
- `outputs/model_comparison.csv`
- `outputs/test_predictions.csv`
- `outputs/new_order_predictions.csv`
- `outputs/logistic_confusion_matrix.txt`
- `outputs/best_random_forest_model.rds`
- `outputs/logistic_model.rds`

## Notes

- The script will attempt to locate the dataset automatically in the project folder.
- If the CSV is missing, it will try to download it from the source dataset.
- The project is designed to be run from the project root folder.

## License

This project is intended for academic and educational use as part of a mini-project in R programming and predictive analytics.

## Contributors

This project was developed for the apparel manufacturing productivity prediction task and is suitable for presentation, coursework, or portfolio use.
