"""
Insert the R output graphs into the presentation automatically.

Usage (after running apparel_prediction.R):
    pip install python-pptx pillow
    python insert_plots.py Apparel_Manufacturing_Prediction_R_Project_PPT.pptx outputs/plots Final_PPT.pptx

Every graph slide has a note like  "PLOT: 01_target_distribution.png".
The script finds that file in the plots folder and places it on the slide.
"""
import os, sys
from pptx import Presentation
from pptx.util import Emu
from PIL import Image

if len(sys.argv) != 4:
    sys.exit(__doc__)
src, plots_dir, out = sys.argv[1:]
prs = Presentation(src)

# picture area on the slide (EMU): left, top, width, height
AX, AY, AW, AH = 1900000, 1550000, 9400000, 5000000
done, missing = 0, []

for slide in prs.slides:
    if not slide.has_notes_slide:
        continue
    note = slide.notes_slide.notes_text_frame.text
    if not note.startswith("PLOT:"):
        continue
    fname = note.splitlines()[0].replace("PLOT:", "").strip()
    path = os.path.join(plots_dir, fname)
    if not os.path.exists(path):
        missing.append(fname)
        continue
    # remove the empty content placeholder
    for sh in list(slide.placeholders):
        if sh.placeholder_format.idx == 1 and not sh.has_text_frame or \
           (sh.placeholder_format.idx == 1 and not sh.text_frame.text.strip()):
            sh._element.getparent().remove(sh._element)
    w, h = Image.open(path).size
    scale = min(AW / w, AH / h)
    pw, ph = int(w * scale), int(h * scale)
    slide.shapes.add_picture(path, Emu(AX + (AW - pw) // 2), Emu(AY + (AH - ph) // 2), Emu(pw), Emu(ph))
    done += 1

prs.save(out)
print(f"Inserted {done} graphs -> {out}")
if missing:
    print("Not found in", plots_dir, ":", ", ".join(missing))
