# =====================================================================
#  APPAREL MANUFACTURING PREDICTION SYSTEM
#  Course : 23CAP317 - R Programming (Mini Project)
#  Goal   : Predict the ACTUAL PRODUCTIVITY of a garment production team
#           (regression) and whether the team will MEET ITS TARGET
#           (classification) from production-floor parameters.
#  Dataset: "Productivity Prediction of Garment Employees"
#           (UCI Machine Learning Repository / Kaggle, 1197 rows, 15 columns)
#
#  HOW TO RUN  (nothing to edit - just run it)
#    1. Put this file and garments_worker_productivity.csv in one folder.
#    2. Open the file in RStudio and click Source (Ctrl+Shift+S),
#       or in a terminal:  Rscript apparel_prediction.R
#    3. If the CSV is missing the script tries to download it; if that also
#       fails, a file-picker window opens so you can select the CSV.
#    4. All plots / tables / models are written to the  outputs/  folder.
#    5. Set QUICK_RUN <- TRUE below for a faster (smaller) random-forest search.
#
#  MAP TO THE MINI-PROJECT QUESTIONS
#    Q1  Section 1 (data structures)  + Section 2 (dataset & objectives)
#    Q2  Section 3 (control structures, functions, lists, data frames)
#    Q3  Section 6 (statistical problems)
#    Q4  Sections 8-9 (regression models) 
#    Q5  Sections 10-11 (apply models, predict output) + GitHub (README.md)
# =====================================================================

# ---------------------------------------------------------------------
# 0. SETUP : packages (control structure: for loop + if) and folders
# ---------------------------------------------------------------------
QUICK_RUN <- FALSE    # TRUE = faster training (fewer trees / smaller tuning grid)

options(repos = c(CRAN = "https://cloud.r-project.org"), warn = 1)
# On Windows, install ready-made (binary) packages so no compiler is needed
if (.Platform$OS.type == "windows") options(pkgType = "binary")

# Work from the folder that contains this script (RStudio, Rscript or source())
script_dir <- tryCatch({
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      rstudioapi::isAvailable()) {
    dirname(rstudioapi::getSourceEditorContext()$path)
  } else {
    args <- commandArgs(trailingOnly = FALSE)
    f <- sub("^--file=", "", args[grep("^--file=", args)])
    if (length(f) == 1) dirname(normalizePath(f)) else getwd()
  }
}, error = function(e) getwd())
if (!is.na(script_dir) && nzchar(script_dir) && dir.exists(script_dir))
  setwd(script_dir)
cat("Working directory:", getwd(), "\n")

required_pkgs <- c("ggplot2", "dplyr", "tidyr", "corrplot", "caret",
                   "ranger", "rpart", "glmnet", "car", "lmtest")

for (p in required_pkgs) {                       # FOR loop
  if (!requireNamespace(p, quietly = TRUE)) {    # IF condition
    install.packages(p, dependencies = TRUE)
  }
  library(p, character.only = TRUE)
}

set.seed(123)                                    # reproducible results
for (d in c("outputs", "outputs/plots")) dir.create(d, showWarnings = FALSE)


# ---------------------------------------------------------------------
# 1. Q1 - BASIC DATA STRUCTURES IN R (apparel-factory examples)
# ---------------------------------------------------------------------
# (a) Vector   : 1-D, same type
daily_output <- c(1180, 1250, 990, 1405, 1320)            # pieces / day
# (b) Factor   : categorical data with fixed levels
dept_factor  <- factor(c("sewing", "finishing", "sewing", "finishing"))
# (c) Matrix   : 2-D, same type  (rows = teams, cols = Mon..Wed)
team_matrix  <- matrix(c(0.80, 0.75, 0.90,
                         0.65, 0.70, 0.85), nrow = 2, byrow = TRUE,
                       dimnames = list(c("Team1", "Team2"),
                                       c("Mon", "Tue", "Wed")))
# (d) Array    : 3-D (team x day x department)
prod_array   <- array(runif(12, 0.5, 1), dim = c(2, 3, 2))
# (e) List     : mixed types
factory_list <- list(name = "Mounish Garments", teams = 12,
                     departments = c("sewing", "finishing"),
                     target_met = TRUE)
# (f) Data frame : table of mixed-type columns  (the main structure used here)
team_df <- data.frame(team = 1:3,
                      department = c("sewing", "sewing", "finishing"),
                      productivity = c(0.82, 0.74, 0.91))

cat("\n--- Q1 : DATA STRUCTURES ---\n")
str(daily_output); str(dept_factor); print(team_matrix)
print(dim(prod_array)); str(factory_list); print(team_df)


# ---------------------------------------------------------------------
# 2. LOAD DATASET  (Q1 - dataset details)
# ---------------------------------------------------------------------
load_garment_data <- function(path = "garments_worker_productivity.csv") {
  # (a) already in the working folder, or in the same folder as the script
  if (!file.exists(path)) {
    hits <- list.files(".", pattern = "garments_worker_productivity.*\\.csv$",
                       recursive = TRUE, ignore.case = TRUE, full.names = TRUE)
    if (length(hits) > 0) path <- hits[1]
  }
  # (b) try to download (UCI zip, then UCI direct file)
  if (!file.exists(path)) {
    message("CSV not found locally - trying to download ...")
    zip_url <- paste0("https://archive.ics.uci.edu/static/public/597/",
                      "productivity+prediction+of+garment+employees.zip")
    tmp <- tempfile(fileext = ".zip")
    ok <- tryCatch({ download.file(zip_url, tmp, mode = "wb", quiet = TRUE); TRUE },
                   error = function(e) FALSE, warning = function(w) FALSE)
    if (ok) {
      unzip(tmp, exdir = ".")
      hits <- list.files(".", pattern = "garments_worker_productivity.*\\.csv$",
                         recursive = TRUE, ignore.case = TRUE, full.names = TRUE)
      if (length(hits) > 0) path <- hits[1]
    }
  }
  # (c) ask the user to pick the file
  if (!file.exists(path) && interactive()) {
    message("Download failed. Please select garments_worker_productivity.csv")
    path <- file.choose()
  }
  if (!file.exists(path)) {
    stop("Dataset missing. Download 'garments_worker_productivity.csv' from ",
         "https://archive.ics.uci.edu/dataset/597 (or Kaggle) and place it in: ",
         getwd())
  }
  cat("Reading dataset from:", path, "\n")
  d <- read.csv(path, stringsAsFactors = FALSE)
  names(d) <- trimws(names(d))
  needed <- c("quarter", "department", "day", "team", "targeted_productivity",
              "smv", "wip", "over_time", "incentive", "idle_time", "idle_men",
              "no_of_style_change", "no_of_workers", "actual_productivity")
  miss <- setdiff(needed, names(d))
  if (length(miss) > 0)
    stop("This CSV is missing expected columns: ", paste(miss, collapse = ", "))
  d
}

garment <- load_garment_data()

cat("\n--- DATASET DETAILS ---\n")
cat("Rows:", nrow(garment), "| Columns:", ncol(garment), "\n")
print(names(garment))
print(head(garment))
str(garment)
print(summary(garment))

# Objectives of the project (printed so they appear in the console output)
objectives <- list(
  "Clean and prepare the garment production data",
  "Explore factors that influence team productivity",
  "Identify statistical problems (missing values, outliers, skew, multicollinearity)",
  "Build and compare regression models to predict actual_productivity",
  "Classify whether a team will meet its targeted productivity",
  "Predict productivity for new production scenarios"
)
cat("\nObjectives:\n")
for (i in seq_along(objectives)) cat(i, ".", objectives[[i]], "\n")


# ---------------------------------------------------------------------
# 3. Q2 - CONTROL STRUCTURES, FUNCTIONS, LISTS, DATA FRAMES
# ---------------------------------------------------------------------
# --- 3.1 User-defined functions ---------------------------------------
# Function 1: cap extreme values (winsorising) at given percentiles
cap_outliers <- function(x, lower = 0.01, upper = 0.99) {
  lims <- quantile(x, c(lower, upper), na.rm = TRUE)
  pmin(pmax(x, lims[1]), lims[2])
}

# Function 2: regression evaluation metrics  (returns a one-row data frame)
evaluate_model <- function(actual, predicted, model_name) {
  rmse <- sqrt(mean((actual - predicted)^2))
  mae  <- mean(abs(actual - predicted))
  r2   <- 1 - sum((actual - predicted)^2) / sum((actual - mean(actual))^2)
  data.frame(Model = model_name, RMSE = round(rmse, 4),
             MAE = round(mae, 4), R2 = round(r2, 4))
}

# Function 3: label productivity (if / else if / else control structure)
productivity_grade <- function(p) {
  if (p >= 0.90) {
    "Excellent"
  } else if (p >= 0.75) {
    "Good"
  } else if (p >= 0.60) {
    "Average"
  } else {
    "Poor"
  }
}

# Function 4: skewness (no extra package needed)
skew <- function(x) { x <- x[!is.na(x)]; mean((x - mean(x))^3) / sd(x)^3 }

# --- 3.2 Control structures demo --------------------------------------
cat("\n--- Q2 : CONTROL STRUCTURES ---\n")
sample_scores <- c(0.95, 0.80, 0.65, 0.40)
for (s in sample_scores) cat("Productivity", s, "->", productivity_grade(s), "\n")

counter <- 0; total_target <- 0
while (counter < 3) {                           # WHILE loop
  counter <- counter + 1
  total_target <- total_target + 0.8
}
cat("While-loop demo, cumulative target:", total_target, "\n")

day_type <- function(d) switch(d,               # SWITCH
                               Saturday = "Weekend", Sunday = "Weekend",
                               "Weekday")
print(sapply(c("Monday", "Saturday", "Sunday"), day_type))   # apply family


# ---------------------------------------------------------------------
# 4. DATA CLEANING / PRE-PROCESSING  (data frame operations)
# ---------------------------------------------------------------------
df <- garment

# 4.1 Missing values & duplicates
na_summary <- colSums(is.na(df))
cat("\nMissing values per column:\n"); print(na_summary[na_summary > 0])
cat("Duplicate rows:", sum(duplicated(df)), "\n")
df <- df[!duplicated(df), ]

# 4.2 Inconsistent category labels  ("sweing", "finishing " with a space)
df$department <- tolower(trimws(df$department))
df$department[df$department == "sweing"] <- "sewing"
print(table(df$department))

# 4.3 Missing 'wip' (work-in-progress): keep a flag, then impute the median
df$wip_missing <- as.integer(is.na(df$wip))
df$wip[is.na(df$wip)] <- median(df$wip, na.rm = TRUE)

# 4.4 Outlier treatment (apply our own function to selected columns)
skewed_cols <- c("wip", "over_time", "incentive")
for (col in skewed_cols) df[[col]] <- cap_outliers(df[[col]])

# 4.5 Feature engineering & type conversion
df$target_met <- factor(ifelse(df$actual_productivity >= df$targeted_productivity,
                               1, 0), levels = c(0, 1),
                        labels = c("NotMet", "Met"))
df$grade      <- factor(sapply(df$actual_productivity, productivity_grade))
for (col in c("quarter", "department", "day", "team"))
  df[[col]] <- factor(df[[col]])
df$date <- NULL                                  # not used as a predictor

cat("\nCleaned data frame:\n"); str(df)
write.csv(df, "outputs/cleaned_garment_data.csv", row.names = FALSE)


# ---------------------------------------------------------------------
# 5. EXPLORATORY DATA ANALYSIS (visualisation)
# ---------------------------------------------------------------------
p1 <- ggplot(df, aes(actual_productivity)) +
  geom_histogram(bins = 40, fill = "#2a6f97", colour = "white") +
  ggtitle("Distribution of Actual Productivity")
ggsave("outputs/plots/01_target_distribution.png", p1, width = 7, height = 4)

p2 <- ggplot(df, aes(department, actual_productivity, fill = department)) +
  geom_boxplot(show.legend = FALSE) +
  ggtitle("Productivity by Department")
ggsave("outputs/plots/02_productivity_by_department.png", p2, width = 6, height = 4)

p3 <- df %>% group_by(day) %>%
  summarise(mean_prod = mean(actual_productivity)) %>%
  ggplot(aes(day, mean_prod)) + geom_col(fill = "#e07a5f") +
  ggtitle("Mean Productivity by Day")
ggsave("outputs/plots/03_productivity_by_day.png", p3, width = 7, height = 4)

num_cols <- names(df)[sapply(df, is.numeric)]
p4 <- df %>% select(all_of(num_cols)) %>%
  pivot_longer(everything(), names_to = "var", values_to = "val") %>%
  ggplot(aes(var, val)) + geom_boxplot(fill = "#81b29a") +
  facet_wrap(~var, scales = "free") + ggtitle("Boxplots of Numeric Features")
ggsave("outputs/plots/04_boxplots.png", p4, width = 10, height = 7)

png("outputs/plots/05_correlation_matrix.png", width = 900, height = 800)
cor_cols <- num_cols[sapply(df[, num_cols], function(v) sd(v) > 0)]
corrplot(cor(df[, cor_cols]), method = "color", tl.cex = 0.8, addCoef.col = "black",
         number.cex = 0.55)
dev.off()

p6 <- ggplot(df, aes(incentive, actual_productivity)) +
  geom_point(alpha = 0.4, colour = "#3d405b") + geom_smooth(method = "lm") +
  ggtitle("Incentive vs Productivity")
ggsave("outputs/plots/06_incentive_vs_productivity.png", p6, width = 7, height = 4)


# ---------------------------------------------------------------------
# 6. Q3 - STATISTICAL PROBLEMS IN THE PROJECT
# ---------------------------------------------------------------------
cat("\n================ Q3 : STATISTICAL PROBLEMS ================\n")
stat_log <- list()                                # list to collect findings

# 6.1 Missing data (wip had NAs, handled above)
stat_log$missing_wip <- sum(is.na(garment$wip))
cat("1) Missing values in wip (before imputation):", stat_log$missing_wip, "\n")

# 6.2 Skewness / non-normality
skew_tbl <- sapply(df[, num_cols], skew)
cat("\n2) Skewness of numeric variables (|skew| > 1 = highly skewed):\n")
print(round(skew_tbl, 2))
sh <- shapiro.test(df$actual_productivity)
cat("Shapiro-Wilk on actual_productivity: W =", round(sh$statistic, 4),
    " p =", format.pval(sh$p.value), "(p < 0.05 -> not normal)\n")
stat_log$shapiro_p <- sh$p.value

# 6.3 Outliers (IQR rule) - counted on the ORIGINAL data
count_outliers <- function(x) {
  q <- quantile(x, c(.25, .75), na.rm = TRUE); i <- diff(q)
  sum(x < q[1] - 1.5 * i | x > q[2] + 1.5 * i, na.rm = TRUE)
}
cat("\n3) Outlier counts (IQR rule, before capping):\n")
print(sapply(garment[, c("wip", "over_time", "incentive", "idle_time",
                         "no_of_workers", "smv")], count_outliers))

# 6.4 Multicollinearity (Variance Inflation Factor on numeric predictors)
num_pred <- setdiff(num_cols, "actual_productivity")
vif_model <- lm(actual_productivity ~ ., data = df[, c("actual_productivity", num_pred)])
cat("\n4) VIF (VIF > 5 suggests multicollinearity):\n")
print(round(car::vif(vif_model), 2))

# 6.5 Correlation test (is the relationship significant?)
ct <- cor.test(df$incentive, df$actual_productivity)
cat("\n5) cor.test(incentive, productivity): r =", round(ct$estimate, 3),
    " p =", format.pval(ct$p.value), "\n")

# 6.6 Hypothesis tests: t-test, ANOVA, Chi-square
tt <- t.test(actual_productivity ~ department, data = df)
cat("\n6) t-test sewing vs finishing: p =", format.pval(tt$p.value), "\n")
an <- summary(aov(actual_productivity ~ day, data = df))
cat("   ANOVA productivity ~ day: p =", format.pval(an[[1]][["Pr(>F)"]][1]), "\n")
ch <- chisq.test(table(df$department, df$target_met))
cat("   Chi-square department vs target_met: p =", format.pval(ch$p.value), "\n")

# 6.7 Heteroscedasticity & residual normality of the baseline linear model
bp <- lmtest::bptest(vif_model)
cat("\n7) Breusch-Pagan test (p < 0.05 -> unequal variance): p =",
    format.pval(bp$p.value), "\n")

# 6.8 Data leakage warning: 'target_met' and 'grade' are derived from the
#     target, so they must NOT be used as predictors in regression.
cat("\n8) Leakage control: target_met & grade removed from regression features.\n")

# 6.9 Class balance for classification
cat("\n9) Class balance of target_met:\n"); print(round(prop.table(table(df$target_met)), 3))


# ---------------------------------------------------------------------
# 7. TRAIN / TEST SPLIT  (80 : 20)
# ---------------------------------------------------------------------
model_df  <- df[, setdiff(names(df), c("target_met", "grade"))]   # no leakage
train_idx <- createDataPartition(model_df$actual_productivity, p = 0.8, list = FALSE)
train <- model_df[train_idx, ]
test  <- model_df[-train_idx, ]
cat("\nTrain rows:", nrow(train), "| Test rows:", nrow(test), "\n")

# make sure test factor levels match train levels
for (col in names(train)[sapply(train, is.factor)])
  test[[col]] <- factor(test[[col]], levels = levels(train[[col]]))

# matrices for glmnet
x_train <- model.matrix(actual_productivity ~ ., train)[, -1]
x_test  <- model.matrix(actual_productivity ~ ., test)[, -1]
y_train <- train$actual_productivity
y_test  <- test$actual_productivity


# ---------------------------------------------------------------------
# 8. Q4 - REGRESSION MODELS
# ---------------------------------------------------------------------
models <- list()                                  # LIST holding every model
preds  <- list()                                  # LIST holding predictions

# 8.1 Multiple Linear Regression
models$linear <- lm(actual_productivity ~ ., data = train)
cat("\n===== Linear Regression summary =====\n"); print(summary(models$linear))
preds$`Linear Regression` <- predict(models$linear, test)

# 8.2 Stepwise Linear Regression (AIC based feature selection)
models$stepwise <- step(models$linear, direction = "both", trace = 0)
cat("\nStepwise-selected formula:\n"); print(formula(models$stepwise))
preds$`Stepwise Regression` <- predict(models$stepwise, test)

# 8.3 Ridge Regression (L2 penalty)
models$ridge <- cv.glmnet(x_train, y_train, alpha = 0)
preds$`Ridge Regression` <- as.numeric(predict(models$ridge, x_test, s = "lambda.min"))

# 8.4 Lasso Regression (L1 penalty - also performs variable selection)
models$lasso <- cv.glmnet(x_train, y_train, alpha = 1)
preds$`Lasso Regression` <- as.numeric(predict(models$lasso, x_test, s = "lambda.min"))
cat("\nLasso coefficients at lambda.min:\n")
print(coef(models$lasso, s = "lambda.min"))

# 8.5 Decision Tree Regression
models$tree <- rpart(actual_productivity ~ ., data = train, method = "anova",
                     control = rpart.control(cp = 0.005))
preds$`Decision Tree` <- predict(models$tree, test)
png("outputs/plots/07_decision_tree.png", width = 1100, height = 700)
plot(models$tree, uniform = TRUE, margin = 0.08); text(models$tree, cex = 0.7)
dev.off()

# 8.6 Random Forest Regression (ranger) with 5-fold CV tuning via caret
ctrl <- trainControl(method = "cv", number = 5)
rf_grid <- if (QUICK_RUN) {
  expand.grid(mtry = c(5), splitrule = "variance", min.node.size = c(5))
} else {
  expand.grid(mtry = c(3, 5, 7), splitrule = "variance",
              min.node.size = c(3, 5, 10))
}
n_trees <- if (QUICK_RUN) 100 else 300
cat("\nTraining random forest (this is the slowest step) ...\n")
cv_rf <- train(actual_productivity ~ ., data = train, method = "ranger",
               trControl = ctrl, tuneGrid = rf_grid, num.trees = n_trees,
               importance = "impurity")
cat("\nBest Random Forest parameters (5-fold CV):\n"); print(cv_rf$bestTune)
models$rf <- cv_rf$finalModel
preds$`Random Forest` <- predict(cv_rf, test)


# ---------------------------------------------------------------------
# 9. MODEL EVALUATION & COMPARISON
# ---------------------------------------------------------------------
results <- do.call(rbind, lapply(names(preds), function(n)
  evaluate_model(y_test, preds[[n]], n)))
results <- results[order(results$RMSE), ]
rownames(results) <- NULL
cat("\n================ MODEL COMPARISON (test set) ================\n")
print(results)
write.csv(results, "outputs/model_comparison.csv", row.names = FALSE)

best_name <- results$Model[1]
cat("\nBest model by RMSE:", best_name, "\n")

# Actual vs Predicted plots (loop over every model)
for (n in names(preds)) {
  pd <- data.frame(Actual = y_test, Predicted = preds[[n]])
  g  <- ggplot(pd, aes(Actual, Predicted)) +
    geom_point(alpha = 0.5, colour = "#3d405b") +
    geom_abline(slope = 1, intercept = 0, colour = "red") +
    ggtitle(paste(n, ": Actual vs Predicted"))
  ggsave(paste0("outputs/plots/AvP_", gsub(" ", "_", n), ".png"), g,
         width = 6, height = 5)
}

# Model comparison bar chart
pc <- ggplot(results, aes(reorder(Model, RMSE), RMSE, fill = Model)) +
  geom_col(show.legend = FALSE) + coord_flip() + xlab("") +
  ggtitle("Model Comparison - Test RMSE (lower is better)")
ggsave("outputs/plots/08_model_comparison.png", pc, width = 7, height = 4)

# Variable importance from the Random Forest
imp <- data.frame(Feature = names(models$rf$variable.importance),
                  Importance = as.numeric(models$rf$variable.importance))
imp <- imp[order(-imp$Importance), ]
cat("\nTop 10 important features (Random Forest):\n"); print(head(imp, 10))
pimp <- ggplot(head(imp, 10), aes(reorder(Feature, Importance), Importance)) +
  geom_col(fill = "#2a6f97") + coord_flip() + xlab("") +
  ggtitle("Top 10 Feature Importance (Random Forest)")
ggsave("outputs/plots/09_feature_importance.png", pimp, width = 7, height = 4)


# ---------------------------------------------------------------------
# 10. CLASSIFICATION : will the team MEET its target?  (Logistic Regression)
# ---------------------------------------------------------------------
cls_df <- df[, setdiff(names(df), c("actual_productivity", "grade"))]  # no leakage
cls_train <- cls_df[train_idx, ]; cls_test <- cls_df[-train_idx, ]
for (col in names(cls_train)[sapply(cls_train, is.factor)])
  cls_test[[col]] <- factor(cls_test[[col]], levels = levels(cls_train[[col]]))

models$logistic <- glm(target_met ~ ., data = cls_train, family = binomial)
prob  <- predict(models$logistic, cls_test, type = "response")
class_pred <- factor(ifelse(prob > 0.5, "Met", "NotMet"), levels = c("NotMet", "Met"))
cm <- confusionMatrix(class_pred, cls_test$target_met, positive = "Met")
cat("\n================ LOGISTIC REGRESSION (target met?) ================\n")
print(cm)
capture.output(print(cm), file = "outputs/logistic_confusion_matrix.txt")

# Confusion matrix as a graph (for the presentation)
cm_df <- as.data.frame(cm$table)
pcm <- ggplot(cm_df, aes(Reference, Prediction, fill = Freq)) +
  geom_tile(colour = "white") + geom_text(aes(label = Freq), size = 8) +
  scale_fill_gradient(low = "white", high = "#2a6f97") +
  ggtitle("Confusion Matrix - Logistic Regression (target met?)")
ggsave("outputs/plots/10_confusion_matrix.png", pcm, width = 6, height = 5)


# ---------------------------------------------------------------------
# 11. Q5 - APPLY THE MODEL : PREDICT THE OUTPUT FOR NEW PRODUCTION DATA
# ---------------------------------------------------------------------
predict_productivity <- function(new_data, model = cv_rf, reference = train) {
  for (col in names(reference)[sapply(reference, is.factor)])      # align levels
    new_data[[col]] <- factor(new_data[[col]], levels = levels(reference[[col]]))
  predict(model, new_data)
}

new_orders <- data.frame(
  quarter = c("Quarter1", "Quarter2"), department = c("sewing", "finishing"),
  day = c("Monday", "Thursday"), team = c(8, 4),
  targeted_productivity = c(0.80, 0.70), smv = c(26.16, 3.94),
  wip = c(1108, 0), over_time = c(7080, 960), incentive = c(98, 0),
  idle_time = c(0, 0), idle_men = c(0, 0), no_of_style_change = c(0, 0),
  no_of_workers = c(59, 8), wip_missing = c(0, 1)
)
new_orders$team <- as.character(new_orders$team)
new_orders$predicted_productivity <-
  round(predict_productivity(new_orders, model = cv_rf), 3)
new_orders$grade <- sapply(new_orders$predicted_productivity, productivity_grade)
new_orders$meets_target <- ifelse(new_orders$predicted_productivity >=
                                    new_orders$targeted_productivity, "Yes", "No")
cat("\n================ PREDICTIONS FOR NEW PRODUCTION ORDERS ================\n")
print(new_orders[, c("department", "day", "team", "targeted_productivity",
                     "predicted_productivity", "grade", "meets_target")])
write.csv(new_orders, "outputs/new_order_predictions.csv", row.names = FALSE)

# Save everything for deployment / GitHub
saveRDS(cv_rf, "outputs/best_random_forest_model.rds")
saveRDS(models$logistic, "outputs/logistic_model.rds")
write.csv(data.frame(Actual = y_test, Predicted = preds[[best_name]]),
          "outputs/test_predictions.csv", row.names = FALSE)
cat("\nDONE. Check the 'outputs' folder for plots, tables and saved models.\n")